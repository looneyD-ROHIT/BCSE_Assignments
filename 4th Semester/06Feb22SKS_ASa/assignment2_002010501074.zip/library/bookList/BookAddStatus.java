package bookList;
public enum BookAddStatus{
	ADDED,
	ID_EXISTS,
	ARRAY_OVERFLOW
}//