public interface library {
	void addBook();
	void searchBook();
	void displayAllBooks();
	void addMember();
	void searchMember();
	void viewAllMembers();
	void issueBook();
	void returnBook();
	void displayAllTransactions();
}
