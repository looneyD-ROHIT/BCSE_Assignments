package memberList;

public enum MemberAddStatus{
	ADDED,
	ID_EXISTS,
	ARRAY_OVERFLOW
}