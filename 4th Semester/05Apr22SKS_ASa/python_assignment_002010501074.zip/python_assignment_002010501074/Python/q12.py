
import string
letters = string.ascii_lowercase
print(list(enumerate(letters, 1)))
