// package q6;

public class Main {
    static void show(int i) {
        System.out.println("output = " + i);
    }
    static void show(double d) {
        System.out.println("output = " + d);
    }
    public static void main(String [] args){
        // using short
        short s = 10;
        show(s);

        // using double
        double d = 11.69;
        show(d);
    }
}
