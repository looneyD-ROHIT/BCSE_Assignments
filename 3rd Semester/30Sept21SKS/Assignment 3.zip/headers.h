#include <iostream>
#include <string>
#include <cmath>
#include <ctime>
#include <chrono>
#include <typeinfo>

using namespace std;
using namespace std::chrono;

#define __dline__ cout << "-------------------------------------------------\n"