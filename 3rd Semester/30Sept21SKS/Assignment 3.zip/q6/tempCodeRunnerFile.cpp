void f(float x)
{
    cout << "inside f(float)" << endl;
}
