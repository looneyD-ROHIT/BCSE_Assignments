#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <math.h>
#include <time.h>

int main(int argc, char **argv)
{
    char c = 'a';
    scanf(" %c", &c);
    printf("hello\n\n%c", c);
    return 0;
}