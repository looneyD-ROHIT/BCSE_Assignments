void makeRecord(strecord *);
int addRecord(char *);
void editRecord(FILE *, int);
int searchRecord(FILE *, int);
void deleteRecord(char *, int);
int displayRecord(char *);