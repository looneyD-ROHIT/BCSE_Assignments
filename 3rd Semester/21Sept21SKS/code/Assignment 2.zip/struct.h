typedef struct student_records // original structure
{
    int roll;
    char name[32];
    float marks[5];
} strecord;