# BCSE_Network_Assignment
Contain network assignments given as a part of BCSE course Jadavpur University
