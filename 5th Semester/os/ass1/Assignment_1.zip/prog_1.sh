#!/bin/sh

echo "Enter the value of uv1"
read uv1
echo "Enter value of uv2"
read uv2
echo "$uv1, $uv2"
echo "$uv1 and $uv2"
