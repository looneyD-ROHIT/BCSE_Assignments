#!/bin/sh

echo "Enter the filepath: "
read filepath

if [ -f "$filepath" ]
then
echo "File found"
number_of_lines=`wc --lines < $filepath`
echo "Number of lines: $number_of_lines"
else
echo "File not fount. Creating a file in C:/OS Assignments named test_new.txt"
file="/mnt/c/OS Assignments/test_new.txt"
echo "Hello, world\nBash scripting is awesome\nThis is a new line" > $file
echo "Reading new file"
number_of_lines=`wc --lines < $file`
echo "Number of lines: $number_of_lines"
fi
