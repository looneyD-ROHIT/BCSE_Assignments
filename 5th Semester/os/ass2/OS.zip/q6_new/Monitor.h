#ifndef monitor_h
#define monitor_h

#define N 7

void initialization();
void test(int i);
void pickup(int i);
void putdown(int i);

#endif
