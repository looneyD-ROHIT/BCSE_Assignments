#include <stdio.h>
#include <unistd.h>
#include <pthread.h>
#include <semaphore.h>
#include "Monitor.h"

sem_t mutex, next;

int next_count = 0;

enum {THINKING, HUNGRY, EATING} state[5];
typedef struct
{
	sem_t sem;
	int count;
} condition;
condition x[N];

void pickup(int i)
{
	sem_wait(&mutex);
	state[i] = HUNGRY;
	test(i);
	if (state[i] != EATING)
		wait(i);
		
	if(next_count > 0)
		sem_post(&next);
	else
		sem_post(&mutex);
}

void putdown(int i)
{
	sem_wait(&mutex);
	state[i] = THINKING;
	test((i + 1) % N);
	test((i + N - 1) % N);
	
	if(next_count > 0)
		sem_post(&next);
	else
		sem_post(&mutex);
}

void test(int i)
{
	if ((state[(i + 1) % N] != EATING) &&
		(state[(i + N - 1) % N] != EATING) &&
		(state[i] == HUNGRY)	) {
		state[i] = EATING;
		signal(i);
	}
}
	
void wait(int i) {
	x[i].count++;
	if (next_count > 0)
		sem_post(&next);  //signal
	else
		sem_post(&mutex); //signal
	sem_wait(&x[i].sem);
	x[i].count--;
}
	
void signal(int i) {
	if (x[i].count > 0) {
		next_count++;
		sem_post(&x[i].sem);
		sem_wait(&next);
		next_count--;
	}
}
	
void initialization() {
	sem_init(&mutex,0,1);
	sem_init(&next,0,0);
	for(int i = 0; i < 5; i++){
		state[i] = THINKING;
		sem_init(&x[i].sem,0,0);
		x[i].count = 0;
	}
}
