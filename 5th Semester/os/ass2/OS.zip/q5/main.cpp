#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/stat.h>
#include <pthread.h>
#include <semaphore.h>

#define READER 1
#define WRITER 2
#define THREAD_VERBOSE
pthread_t start_thread(unsigned type);

sem_t rmutex;         
sem_t wmutex;          
sem_t readTry;
sem_t resource;


int rc = 0;                 
int wc = 0;

void *reader(void*);      
void *writer(void*);       

char *filename;
#define HASH_SIZE 1000
void read_file(int id);
#define MAX_WRITE_SIZE 1024 
void write_file(int id);

pthread_t start_thread(unsigned type) {
    static unsigned rc = 0;
    static unsigned wc = 0;

    pthread_t tid;
    pthread_attr_t attr;
    pthread_attr_init(&attr); 

    int *id = (int*)malloc(sizeof(*id));
    switch (type) {
    case READER:
        *id = ++rc;
        pthread_create(&tid, &attr, reader, id);
        break;
    case WRITER:
        *id = ++wc;
        pthread_create(&tid, &attr, writer, id);
        break;
    }
    return tid;
}

void *reader(void *arg) {
    int id = *((int*)arg);
#ifdef THREAD_VERBOSE
    printf("[reader: %d] Thread started.\n", id);
#endif

    
    sem_wait(&readTry);
    sem_wait(&rmutex);
    rc++;    
    if (rc == 1)
        sem_wait(&resource);         
    sem_post(&rmutex);          
    sem_post(&readTry);               

    read_file(id); 

    sem_wait(&rmutex);                   
    rc--;
    if (rc == 0)
        sem_post(&resource);           
    sem_post(&rmutex);


#ifdef THREAD_VERBOSE
    printf("[reader: %d] Thread exiting.\n", id);
#endif
    free(arg);
    pthread_exit(NULL);
}

void *writer(void *arg) {
    int id = *((int*)arg);
#ifdef THREAD_VERBOSE
    printf("[writer: %d] Thread started.\n", id);
#endif

    sem_wait(&wmutex);              
    wc++;                
    if (wc == 1)         
        sem_wait(&readTry);             
    sem_post(&wmutex);                  
    sem_wait(&resource);                
    write_file(id);
    sem_post(&resource);  

    sem_wait(&wmutex);    
    wc--;                
    if (wc == 0)         
        sem_post(&readTry);
    sem_post(&wmutex);       


#ifdef THREAD_VERBOSE
    printf("[writer: %d] Thread exiting.\n", id);
#endif
    free(arg);
    pthread_exit(NULL);
}

void read_file(int id) {
    printf("[reader: %d] Started reading.\n", id);
    FILE *fd = fopen(filename, "r");
    if (fd == NULL) {
        perror("Unable to open the file for reading");
        exit(1);
    }
    int hash = 0;
    for (int c = fgetc(fd); c!=EOF; c=fgetc(fd)) {
        if (ferror(fd)) {
            perror("Error while reading the file");
            exit(1);
        }
        hash += c;
    }
    hash %= HASH_SIZE;
    if (fclose(fd)!=0) {
        perror("Unable to close the file opened by reader");
        exit(1);
    }
    printf("[reader: %d] Finished reading file with hash: %d\n", id, hash);
}

void write_file(int id) {
    printf("[writer: %d] Started writing.\n", id);
    
    FILE *fd = fopen(filename, "w+");
    if (fd == NULL) {
        perror("Unable to open the file for writing");
        exit(1);
    }
    int hash = 0;
    for (unsigned i = 0; i < MAX_WRITE_SIZE; i++) {
        unsigned char c = rand();
        fputc((char)c, fd);
        if (ferror(fd)) {
            perror("Error while writing to the file");
            exit(1);
        }
        hash += (int)c;
    }
    hash %= HASH_SIZE;
    if (fclose(fd)!=0) {
        perror("Unable to close the file opened by writer");
        exit(1);
    }
    printf("[writer: %d] Write to file with hash: %d\n", id, hash);
    printf("[writer: %d] Done writing.\n", id);
}

void startrw(unsigned r, unsigned w) {
    pthread_t threads[r+w];
    printf("Starting %u writers.\n", w);
    for (unsigned i = 0; i < w; i++) threads[r+i] = start_thread(WRITER);
    printf("Starting %u readers.\n", r);
    for (unsigned i = 0; i < r; i++) threads[i] = start_thread(READER);
    for (unsigned i = 0; i < r+w; i++) pthread_join(threads[i], NULL);
    printf("All readers and writers' threads are done executing.\n");
}

void startx(unsigned x) {
    pthread_t threads[x*2];
    printf("Starting %u readers and writers total.\n", x*2);
    for (unsigned i = 0; i < x; i++) {
        threads[i*2+1] = start_thread(WRITER);
        threads[i*2] = start_thread(READER);
    }
    for (unsigned i = 0; i < x*2; i++) pthread_join(threads[i], NULL);
    printf("All readers and writers' threads are done executing.\n");
}


int main(int argc, char *argv[]) {
    srand(time(NULL));
    setbuf(stdout, NULL);
    sem_init(&readTry,0,1);
    sem_init(&rmutex,0,1);
    sem_init(&wmutex,0,1);
    sem_init(&resource,0,1);

    if (argc != 2) {
        fprintf(stderr, "Usage: %s file\n", argv[0]);
        return 1;
    } else {
        filename = argv[1];
        if (access(filename, R_OK|W_OK) == -1) {
            perror("Please provide existing file with rw permissions");
            return 1;
        }
    }

    
    startrw(10,1);
}
