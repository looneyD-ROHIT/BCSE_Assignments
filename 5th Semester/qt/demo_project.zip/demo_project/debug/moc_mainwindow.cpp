/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.15.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../mainwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.15.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_MainWindow_t {
    QByteArrayData data[44];
    char stringdata0[665];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MainWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 0, 10), // "MainWindow"
QT_MOC_LITERAL(1, 11, 13), // "Mouse_Pressed"
QT_MOC_LITERAL(2, 25, 0), // ""
QT_MOC_LITERAL(3, 26, 17), // "showMousePosition"
QT_MOC_LITERAL(4, 44, 7), // "QPoint&"
QT_MOC_LITERAL(5, 52, 3), // "pos"
QT_MOC_LITERAL(6, 56, 20), // "on_show_axes_clicked"
QT_MOC_LITERAL(7, 77, 15), // "on_Draw_clicked"
QT_MOC_LITERAL(8, 93, 21), // "on_set_point1_clicked"
QT_MOC_LITERAL(9, 115, 21), // "on_set_point2_clicked"
QT_MOC_LITERAL(10, 137, 21), // "on_pushButton_clicked"
QT_MOC_LITERAL(11, 159, 28), // "on_pushButton_shGrid_clicked"
QT_MOC_LITERAL(12, 188, 23), // "on_spinBox_valueChanged"
QT_MOC_LITERAL(13, 212, 4), // "arg1"
QT_MOC_LITERAL(14, 217, 23), // "on_pushButton_2_clicked"
QT_MOC_LITERAL(15, 241, 11), // "drawDDALine"
QT_MOC_LITERAL(16, 253, 1), // "r"
QT_MOC_LITERAL(17, 255, 1), // "g"
QT_MOC_LITERAL(18, 257, 1), // "b"
QT_MOC_LITERAL(19, 259, 24), // "on_bresenhamLine_clicked"
QT_MOC_LITERAL(20, 284, 22), // "on_polarCircle_clicked"
QT_MOC_LITERAL(21, 307, 5), // "delay"
QT_MOC_LITERAL(22, 313, 26), // "on_bresenhamCircle_clicked"
QT_MOC_LITERAL(23, 340, 23), // "on_polarEllipse_clicked"
QT_MOC_LITERAL(24, 364, 27), // "on_midpointEllispse_clicked"
QT_MOC_LITERAL(25, 392, 16), // "storeEdgeInTable"
QT_MOC_LITERAL(26, 409, 2), // "x1"
QT_MOC_LITERAL(27, 412, 2), // "y1"
QT_MOC_LITERAL(28, 415, 2), // "x2"
QT_MOC_LITERAL(29, 418, 2), // "y2"
QT_MOC_LITERAL(30, 421, 20), // "on_setVertex_clicked"
QT_MOC_LITERAL(31, 442, 22), // "on_clearVertex_clicked"
QT_MOC_LITERAL(32, 465, 13), // "initEdgeTable"
QT_MOC_LITERAL(33, 479, 23), // "on_scanLineFill_clicked"
QT_MOC_LITERAL(34, 503, 23), // "on_boundaryFill_clicked"
QT_MOC_LITERAL(35, 527, 25), // "boundaryfillUtility8point"
QT_MOC_LITERAL(36, 553, 1), // "x"
QT_MOC_LITERAL(37, 555, 1), // "y"
QT_MOC_LITERAL(38, 557, 4), // "QRgb"
QT_MOC_LITERAL(39, 562, 9), // "edgecolor"
QT_MOC_LITERAL(40, 572, 25), // "boundaryfillUtility4point"
QT_MOC_LITERAL(41, 598, 20), // "on_floodfill_clicked"
QT_MOC_LITERAL(42, 619, 22), // "floodfillUtility4point"
QT_MOC_LITERAL(43, 642, 22) // "floodfillUtility8point"

    },
    "MainWindow\0Mouse_Pressed\0\0showMousePosition\0"
    "QPoint&\0pos\0on_show_axes_clicked\0"
    "on_Draw_clicked\0on_set_point1_clicked\0"
    "on_set_point2_clicked\0on_pushButton_clicked\0"
    "on_pushButton_shGrid_clicked\0"
    "on_spinBox_valueChanged\0arg1\0"
    "on_pushButton_2_clicked\0drawDDALine\0"
    "r\0g\0b\0on_bresenhamLine_clicked\0"
    "on_polarCircle_clicked\0delay\0"
    "on_bresenhamCircle_clicked\0"
    "on_polarEllipse_clicked\0"
    "on_midpointEllispse_clicked\0"
    "storeEdgeInTable\0x1\0y1\0x2\0y2\0"
    "on_setVertex_clicked\0on_clearVertex_clicked\0"
    "initEdgeTable\0on_scanLineFill_clicked\0"
    "on_boundaryFill_clicked\0"
    "boundaryfillUtility8point\0x\0y\0QRgb\0"
    "edgecolor\0boundaryfillUtility4point\0"
    "on_floodfill_clicked\0floodfillUtility4point\0"
    "floodfillUtility8point"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      28,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  154,    2, 0x0a /* Public */,
       3,    1,  155,    2, 0x0a /* Public */,
       6,    0,  158,    2, 0x08 /* Private */,
       7,    0,  159,    2, 0x08 /* Private */,
       8,    0,  160,    2, 0x08 /* Private */,
       9,    0,  161,    2, 0x08 /* Private */,
      10,    0,  162,    2, 0x08 /* Private */,
      11,    0,  163,    2, 0x08 /* Private */,
      12,    1,  164,    2, 0x08 /* Private */,
      14,    0,  167,    2, 0x08 /* Private */,
      15,    3,  168,    2, 0x08 /* Private */,
      19,    0,  175,    2, 0x08 /* Private */,
      20,    0,  176,    2, 0x08 /* Private */,
      21,    1,  177,    2, 0x08 /* Private */,
      22,    0,  180,    2, 0x08 /* Private */,
      23,    0,  181,    2, 0x08 /* Private */,
      24,    0,  182,    2, 0x08 /* Private */,
      25,    4,  183,    2, 0x08 /* Private */,
      30,    0,  192,    2, 0x08 /* Private */,
      31,    0,  193,    2, 0x08 /* Private */,
      32,    0,  194,    2, 0x08 /* Private */,
      33,    0,  195,    2, 0x08 /* Private */,
      34,    0,  196,    2, 0x08 /* Private */,
      35,    6,  197,    2, 0x08 /* Private */,
      40,    6,  210,    2, 0x08 /* Private */,
      41,    0,  223,    2, 0x08 /* Private */,
      42,    5,  224,    2, 0x08 /* Private */,
      43,    5,  235,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 4,    5,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   13,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int, QMetaType::Int, QMetaType::Int,   16,   17,   18,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int, QMetaType::Int, QMetaType::Int, QMetaType::Int,   26,   27,   28,   29,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int, QMetaType::Int, 0x80000000 | 38, QMetaType::Int, QMetaType::Int, QMetaType::Int,   36,   37,   39,   16,   17,   18,
    QMetaType::Void, QMetaType::Int, QMetaType::Int, 0x80000000 | 38, QMetaType::Int, QMetaType::Int, QMetaType::Int,   36,   37,   39,   16,   17,   18,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int, QMetaType::Int, QMetaType::Int, QMetaType::Int, QMetaType::Int,   36,   37,   16,   17,   18,
    QMetaType::Void, QMetaType::Int, QMetaType::Int, QMetaType::Int, QMetaType::Int, QMetaType::Int,   36,   37,   16,   17,   18,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<MainWindow *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->Mouse_Pressed(); break;
        case 1: _t->showMousePosition((*reinterpret_cast< QPoint(*)>(_a[1]))); break;
        case 2: _t->on_show_axes_clicked(); break;
        case 3: _t->on_Draw_clicked(); break;
        case 4: _t->on_set_point1_clicked(); break;
        case 5: _t->on_set_point2_clicked(); break;
        case 6: _t->on_pushButton_clicked(); break;
        case 7: _t->on_pushButton_shGrid_clicked(); break;
        case 8: _t->on_spinBox_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 9: _t->on_pushButton_2_clicked(); break;
        case 10: _t->drawDDALine((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< int(*)>(_a[3]))); break;
        case 11: _t->on_bresenhamLine_clicked(); break;
        case 12: _t->on_polarCircle_clicked(); break;
        case 13: _t->delay((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 14: _t->on_bresenhamCircle_clicked(); break;
        case 15: _t->on_polarEllipse_clicked(); break;
        case 16: _t->on_midpointEllispse_clicked(); break;
        case 17: _t->storeEdgeInTable((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< int(*)>(_a[3])),(*reinterpret_cast< int(*)>(_a[4]))); break;
        case 18: _t->on_setVertex_clicked(); break;
        case 19: _t->on_clearVertex_clicked(); break;
        case 20: _t->initEdgeTable(); break;
        case 21: _t->on_scanLineFill_clicked(); break;
        case 22: _t->on_boundaryFill_clicked(); break;
        case 23: _t->boundaryfillUtility8point((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< QRgb(*)>(_a[3])),(*reinterpret_cast< int(*)>(_a[4])),(*reinterpret_cast< int(*)>(_a[5])),(*reinterpret_cast< int(*)>(_a[6]))); break;
        case 24: _t->boundaryfillUtility4point((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< QRgb(*)>(_a[3])),(*reinterpret_cast< int(*)>(_a[4])),(*reinterpret_cast< int(*)>(_a[5])),(*reinterpret_cast< int(*)>(_a[6]))); break;
        case 25: _t->on_floodfill_clicked(); break;
        case 26: _t->floodfillUtility4point((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< int(*)>(_a[3])),(*reinterpret_cast< int(*)>(_a[4])),(*reinterpret_cast< int(*)>(_a[5]))); break;
        case 27: _t->floodfillUtility8point((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< int(*)>(_a[3])),(*reinterpret_cast< int(*)>(_a[4])),(*reinterpret_cast< int(*)>(_a[5]))); break;
        default: ;
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject MainWindow::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_MainWindow.data,
    qt_meta_data_MainWindow,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 28)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 28;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 28)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 28;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
